# Crear estas clases
# Define los atributos, metodos, constructures... que consideres
# cursos : id,nombre,creditos,añosdeestudio
# alumno : id,nombre,email
# matricula : idmatricula,fechamatricula,idalumno,idcurso
# Necesitamos:
# mostrar la ficha del curso
# mostrar la ficha de alumno
# el alumno 1 se matricula en un curso
# el alumno 2 se matricula en dos cursos
# mostrar los datos de matricula
# RETO: metodo que muestra las matriculas realizadas
import random


class Curso():
    def __init__(self,id_curso,nombre,creditos,años_de_estudio): # metodo constructor
        self.id_curso=id_curso
        self.nombre=nombre
        self.creditos=creditos
        self.años_de_estudios=años_de_estudio
    def fichaCurso(self): # metodo instancia
        print('\n--- FICHA DEL CURSO ---')
        print(f'ID Curso: {self.id_curso}')
        print(f'Nombre: {self.nombre}')
        print(f'Creditos: {self.creditos}')
        print(f'Años de estudios: {self.años_de_estudios}')

class Alumno(): # metodo constructor
    def __init__(self,id_alumno,nombre,email):
        self.id_alumno=id_alumno
        self.nombre=nombre
        self.email=email
    def fichaAlumno(self): # metodo instancia
        print('\n--- FICHA DEL ALUMNO ---')
        print(f'ID Alumno: {self.id_alumno}')
        print(f'Nombre: {self.nombre}')
        print(f'Email: {self.email}')

class Matricula(): # metodo constructor
    def __init__(self,id_matricula,fecha_matricula,id_alumno,id_curso):
        self.id_matricula=id_matricula
        self.fecha_matricula=fecha_matricula
        self.id_alumno=id_alumno
        self.id_curso=id_curso
    def datosMatricula(self): # metodo instancia
        print('\n--- DATOS DE LA MATRICULA ---')
        print(f'ID Matricula: {self.id_matricula}')
        print(f'Fecha matricula: {self.fecha_matricula}')
        print(f'ID Alumno: {self.id_alumno}')
        print(f'ID Curso: {self.id_curso}')

curso1=Curso(random.randint(1,100),'DAM',200,2) # id_curso : calcula un numero aleatorio entre 1 y 100
curso2=Curso(random.randint(1,100),'DAM',150,2)
alumno1=Alumno(random.randint(100,1000),'Jose Antonio','joseantonioures@campusfp.es') # id_alumno : calcula un numero aleatorio entre 100 y 1000
alumno2=Alumno(alumno1.id_alumno,'Jose Antonio','joseantonioures@campusfp.es')
matricula1=Matricula(random.randint(1,100),'12/17/2022',alumno1.id_alumno,curso1.id_curso) # id_matricula : calcula un numero aleatorio entre 1 y 100
# para poner el mismo id_matricula en la matricula2 se implementa la propiedad id_matricula de la matricula1
matricula2=Matricula(matricula1.id_matricula,'15/17/2022',alumno1.id_alumno,curso2.id_curso) # id_matricula : calcula un numero aleatorio entre 1 y 100
curso1.fichaCurso()
curso2.fichaCurso()
alumno1.fichaAlumno()
alumno2.fichaAlumno()
matricula1.datosMatricula()
matricula2.datosMatricula()

